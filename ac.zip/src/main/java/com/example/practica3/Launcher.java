package com.example.practica3;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(AppInitializer.class, args);
    }
}
