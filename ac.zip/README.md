## Cambios

- YA FUNCIONAN LOS MENSAJEEEEEEEEEEEEEEEEEES
- La ventana de amigos ya funciona correctamente y tiene fondo
- Ahora algunos mensajes que antes se hacian con warnings ahora se hacen con la ventana de notificaciones
- Ahora para eliminar amigos hay que hacerlo clickando en su entrada en la lista de amigos (asi que sean botones sirve de algo)
- Si no introduces ninguna IP, te manda automaticamente a `localhost`
- Eliminadas clases inutiles
- Eliminadas variables inutiles

## Cosas por hacer
- Comentar
- Resolver todo tipo de bugs con botones y demas
- Si hay tiempo, cambiar la interfaz que reciben los clientes, no deberia ser interfazCliente, deberia ser una nueva que no tenga tantas funcionalidades, interfazCliente deberia quedar solo para el servidor

## Extra
- Hacer que no se puedan pulsar botones si estas en un menu (con las flechas y en enter a veces te deja)
- Encriptar mensajes

# AeroChat
Chat P2P con servidor RMI para sincronizado
