## Cambios
- Ya meti el botoncito de cambiar contraseña, pero no funciona de parte del server, el arreglo deberia ser trivial y lo dejo como ejercicio al lector   <- QUE TRAUMA
- Nuevo boton para recargar la lista de conectados
- Ahora no deja poner un nombre que contenga "|"
- Botones de conectar y elimnar amigos que no hacen nada


- Avance un poco con las cosas de amigos, en cuanto este implementado en el servidor deberia ser bastante facil que funcione

## Por implementar
- Modificar la interfaz gráfica de añadir amistad
- Implementar el envío de solicitudes de amistad
- Mostrar mensaje de login de amigos (no encontré el cuadro de texto donde ponerlo)

## Errores
- Revisar envío de mensajes. Conecté dos ordenadores y envié mensajes pero nunca se mostraron en la pantalla del otro
- (Es que no lo hice xd)

# AeroChat
Chat P2P con servidor RMI para sincronizado
